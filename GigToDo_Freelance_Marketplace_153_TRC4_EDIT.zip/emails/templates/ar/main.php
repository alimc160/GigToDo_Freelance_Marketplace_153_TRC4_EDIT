<?php
   include("parts/header.php");    
   include("$dir/emails/templates/{$lang}/".$data['template'].".php");   
   include("parts/footer.php"); 
?>