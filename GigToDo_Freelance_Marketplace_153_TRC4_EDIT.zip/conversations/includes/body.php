<div class="specfic col-md-9 p-0 <?=($lang_dir == "right" ? 'order-1 order-sm-2':'')?>">
	
   <center id="selectConversation" class="mt-5 mt-sm-5">
		<img src="../images/chat.png" width="180" alt="">
		<h3 class="mt-3 empty-heading" style="font-weight:410;"><?= $lang['inbox']['select']['title']; ?></h3>
		<p class="lead"><?= $lang['inbox']['select']['desc']; ?></p>
	</center>

	<div id="msgHeader" class="card-header bg-transparent inboxHeader2 d-none"></div>
	<div id="showSingle" class="row"></div>

</div>